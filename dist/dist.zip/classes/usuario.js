"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Usuario {
    constructor(id) {
        this.id = id;
        this.nombre = 'sin-nombre';
        this.sala = 'sin-sala';
    }
}
exports.Usuario = Usuario;
